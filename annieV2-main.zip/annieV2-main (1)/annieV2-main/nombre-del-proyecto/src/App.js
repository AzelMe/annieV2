import { useState } from "react";
import Login from "./components/Login/Login";
import Registro from "./components/Registro/Registro";
import "./App.css";

function App() {
  const [currentPage, setCurrentPage] = useState("login");

  return (
    <div className="App">
      {currentPage === "login" ? (
        <Login onRegisterClick={() => setCurrentPage("registro")} />
      ) : (
        <Registro onLoginClick={() => setCurrentPage("login")} />
      )}
    </div>
  );
}

export default App;
