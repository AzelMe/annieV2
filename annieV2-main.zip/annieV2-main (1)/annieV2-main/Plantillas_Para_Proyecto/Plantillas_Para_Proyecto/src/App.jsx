import PerfilDelNegocio from "./PerfilDelNegocio"; 
function App() {
  return (
    <div>
      <PerfilDelNegocio />
    </div>
  );
}

export default App;

//Para poder ver la pantalla que crearon hagan esto : import "nombre del archivo" from "./nombredelarchivo"
// luego en el <div> pongan asi: <div> <Nombre del archivo /> <div>
// luego abran la terminal y pongan npm run dev, y ya quedo
